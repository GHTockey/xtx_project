<template>
  <RouterView />
  <!-- <XtxCheckbox v-model="isAgree">是否同意协议</XtxCheckbox> -->
</template>


<script setup lang="ts">
// import XtxCheckbox from "@/components/XtxCheckbox.vue";
// import { ref } from "vue";

// const isAgree = ref(false);
</script>

<style scoped lang="less"></style>